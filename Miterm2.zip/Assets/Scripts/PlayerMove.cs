using NUnit.Framework;
using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections;

[RequireComponent(typeof(Rigidbody2D))]
public class PlayerMove : MonoBehaviour
{
    public float moveSpeed = 8f;
    public float jumpForce = 14f;
    //public bool isGrounded;
    public Transform groundCheck;
    public float groundCheckRadius = 0.2f;
    public float wallSlideSpeed = 2f;
    public float wallCheckDistance = 0.5f;
    public Vector2 wallJumpForce = new Vector2(10f, 14);
    public float wallJumpDuration = 0.2f;
    public LayerMask groundLayer;
    private bool isWallSliding;
    private bool isWallJumping;
    private float moveInput;
    private int facingDirection = 1;
    public GameObject Player;
    
    private  Rigidbody2D my_rb;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private void Awake()
    {
        my_rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        ReadInput();

    }
    // Update is called once per frame
    void FixedUpdate()
    {
        Move();
        WallSlide();
        
        
        if (Input.GetKey(KeyCode.D))
        {
            Debug.Log("The Right key is pressed.");

            my_rb.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }
        if (Input.GetKey(KeyCode.A))
        {
            Debug.Log("The Left key is pressed.");

            my_rb.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }
        /*
        if ((Input.GetKey(KeyCode.UpArrow) || Input.GetKey(KeyCode.Space)) && isGrounded)
        {
            Debug.Log("The Up key is pressed.");
            Jump();
        }
        */
        
    }
    
    private void ReadInput()
    {
        Keyboard kb = Keyboard.current;
        moveInput = 0;
        if (kb.dKey.isPressed)
        {
            moveInput = 1;
        }
        if (kb.aKey.isPressed)
        {
            moveInput = -1;
        }

        if (kb.spaceKey.wasPressedThisFrame) Jump();
        if (moveInput != 0f) facingDirection = (int)moveInput;
    }


    private void Jump()
    {
        if (IsGrounded())
        {
            my_rb.linearVelocityY = jumpForce;
        }
        else if (isWallSliding)
        {
            StartCoroutine(WallJump());
        }

    }

    private bool IsGrounded()
    {
        return Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);
    }

    private void Move()
    {
        if (isWallJumping) return;
        //my_rb.linearVelocityX = moveInput * moveSpeed;
    }
    private bool IsTouchingWall()
    {
        Vector2 checkPos = (Vector2)transform.position + Vector2.right * facingDirection * wallCheckDistance;
        return Physics2D.OverlapCircle(checkPos, groundCheckRadius, groundLayer);
    }
    private void WallSlide()
    {
        isWallSliding = IsTouchingWall() && !IsGrounded() && !isWallJumping;
        if (isWallSliding)
        {
            my_rb.linearVelocityY = Mathf.Max(my_rb.linearVelocityY, -wallSlideSpeed);
        }
    }

    private IEnumerator WallJump()
    {
        isWallJumping = true;
        facingDirection = -facingDirection;
        my_rb.linearVelocity = new Vector2(facingDirection * wallJumpForce.x, wallJumpForce.y);

        yield return new WaitForSeconds(wallJumpDuration);

        isWallJumping = false;
    }
}
